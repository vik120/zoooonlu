import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import 'rxjs/add/operator/map';
import {app} from './../../constant';
@Injectable()

export class usersService{

	constructor(private http:Http){
	}
	getUser(){
		console.log("in service data")
	return this.http.get(app.AppSettings.HOST+"userRoutes/getUser").
	map((response: Response) => response.json());
	}

// private token() {
//         // create authorization header with jwt token
//         let access_token = JSON.parse(localStorage.getItem('access_token'));
//         if (access_token) {  
//             let headers = new Headers({ 'Authorization': 'Bearer ' + access_token });
//             return new RequestOptions({ headers: headers });
//         }
//     }

}