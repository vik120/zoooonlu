import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { usersService } from './../charts.service';
import {FormBuilder, Validators, FormControl, FormGroup} from '@angular/forms';
import { PasswordValidation } from './../../../validators';
import { signupService } from './../../../signup/signup.service';

@Component({
    selector: 'app-users',
    templateUrl: './addUser.component.html',
    styleUrls: ['./addUser.component.scss']
})
export class UsersComponent implements OnInit {
    form:FormGroup = null;
    firstName:FormControl = null;
    lastName:FormControl = null;
    userEmail:FormControl = null;
    password:FormControl = null;
    phoneNo : FormControl = null;
    city: FormControl=null;
    state:FormControl =null;
    zip:FormControl = null;
    confirmPassword:FormControl = null;
    constructor(public router: Router,private _builder:FormBuilder,private signupService:signupService) {
        this.firstName = new FormControl(null, []);
        this.lastName = new FormControl(null, []);
        this.userEmail = new FormControl(null, Validators.compose([]));
        this.password = new FormControl(null, Validators.compose([]));
        this.confirmPassword = new FormControl(null, Validators.compose([]));
        this.phoneNo = new FormControl(null, Validators.compose([]));
        this.city = new FormControl(null, Validators.compose([]));
        this.state = new FormControl(null, Validators.compose([]));
        this.zip = new FormControl(null, Validators.compose([]));

        this.form = this._builder.group({
            firstName: this.firstName,
            lastName: this.lastName,
            userEmail: this.userEmail,
            phoneNo: this.phoneNo,
            city: this.city,
            state: this.state,
            zip: this.zip,
            password:this.password,
            confirmPassword:this.confirmPassword
        });

    }
    ngOnInit() {}
      onSubmit(value:any){
        console.log("m here *-*-**-***-*-*-", value)
        this.signupService.addUser(value).subscribe(userData => {
           console.log("response-------------",userData)
               
               if(userData.messageId==200){
                   // this.toastr.success('You are awesome!', 'Success!');
                   // this._router.navigate(['/login']);
               }else{
                   // this.toastr.error('You are awesome!', 'Success!');
               }

        })
      }

}
