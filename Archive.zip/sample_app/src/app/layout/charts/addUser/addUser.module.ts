import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChartsModule as Ng2Charts } from 'ng2-charts';

import { ChartsRoutingModule } from './addUser-routing.module';
import { UsersComponent } from './addUser.component';
import { PageHeaderModule } from '../../../shared';
import { usersService } from './../charts.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { signupService } from './../../../signup/signup.service';

@NgModule({
    imports: [
        CommonModule,
        Ng2Charts,
        ChartsRoutingModule,
        PageHeaderModule,
         FormsModule,
        ReactiveFormsModule
    ],
    declarations: [UsersComponent],
    providers:[usersService,signupService]
})
export class addUserModule { }
