import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { usersService } from './charts.service';

@Component({
    selector: 'app-charts',
    templateUrl: './charts.component.html',
    styleUrls: ['./charts.component.scss']
})
export class ChartsComponent implements OnInit {
    userDetail:any=[]
    constructor(public router: Router,public usersService: usersService,) {

    }
    ngOnInit() {
       this.getUser();
      }
      getUser(){
        console.log("-----------2323---------------",localStorage.getItem("userId"))
           this.usersService.getUser().subscribe(userData => {
               console.log("userData",userData.data)
               this.userDetail = userData.data
           })
       }

}
