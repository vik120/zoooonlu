import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ChatRoutingModule } from './Chat-routing.module';
import { ChatComponent } from './Chat.component';
import { ChatService } from './Chat.service';
import {ToastModule} from 'ng2-toastr/ng2-toastr';
@NgModule({
  imports: [
    CommonModule,
    ChatRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    ToastModule.forRoot()
  ],
  declarations: [ChatComponent],
  providers:[ChatService]
})
export class ChatModule { }
