export module app{
export class AppSettings {
<<<<<<< HEAD
   //public static HOST = 'http://52.39.212.226:4086/';
   public static HOST = 'http://localhost:4109/';
=======
 public static HOST = 'http://52.39.212.226:4000/';
   //public static HOST = 'http://localhost:4042/';
>>>>>>> 535a9af76b79ad37c4a618813625df812cab4faf
   
   public static CHANGE_PASSWORD = AppSettings.HOST+'profile/change_password';
 
   public static EMAIL_PATTERN = /^[a-z]+[a-z0-9._]+@[a-z]+\.[a-z.]{2,5}$/;
   public static PHONE_PATTERN = /^[0-9]{10,10}$/;
   public static DATE_PATTERN = /^\d{2}\/\d{2}\/\d{4}$/;
}
}
