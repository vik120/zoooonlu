import { Component, OnInit,ViewContainerRef } from '@angular/core';
import { Router } from '@angular/router';
import {FormBuilder, Validators, FormControl, FormGroup} from '@angular/forms';
import { PasswordValidation } from './../validators';
import { signupService } from './signup.service';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
 
@Component({
    selector: 'app-signup',
    templateUrl: './signup.component.html',
    styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {
	 form:FormGroup = null;
    firstName:FormControl = null;
    userEmail:FormControl = null;
    password:FormControl = null;
    confirmPassword:FormControl = null;
    constructor(public router: Router, private _builder:FormBuilder,private signupservice:signupService,
                public toastr: ToastsManager, vcr: ViewContainerRef,private _router: Router) {

        this.toastr.setRootViewContainerRef(vcr);
    	  this.firstName = new FormControl(null, [Validators.required,Validators.minLength(3),Validators.maxLength(10)]);
        this.userEmail = new FormControl(null, Validators.compose([Validators.required]));
        this.password = new FormControl(null, Validators.compose([Validators.required,Validators.minLength(3),Validators.maxLength(12)]));
        this.confirmPassword = new FormControl(null, Validators.compose([Validators.required,Validators.minLength(3),Validators.maxLength(12)]));

        this.form = this._builder.group({
            firstName: this.firstName,
            userEmail: this.userEmail,
            password:this.password,
            confirmPassword:this.confirmPassword
        }, {validator: PasswordValidation.MatchPassword });
     }

    ngOnInit() { }
    onSubmit(value:any){ 
       this.signupservice.addUser(value).subscribe(userData => {
           console.log("response-------------",userData)
               
               if(userData.messageId==200){
                   this.toastr.success('You are awesome!', 'Success!');
                   this._router.navigate(['/login']);
               }else{
                    this.toastr.error('You are awesome!', 'Success!');
               }

        })
    }

}
