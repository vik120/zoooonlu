import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import 'rxjs/add/operator/map';
import {app} from './../constant';
@Injectable()

export class signupService{

	constructor(private http:Http){
	}
	addUser(obj){
		console.log("in signup service ", obj)
	return this.http.post(app.AppSettings.HOST+"userRoutes/addUser",obj).
	map((response: Response) => response.json());
	}
	// changeStatus(id){  
	//   let token=localStorage.getItem('token')   
	//    return 
	//    this.http.post(this.baseurl+'/admin/change-status/',{"token":token,"_id":id}).  
	//      map((res:Response)=>{return res.json() })  }

private token() {
        // create authorization header with jwt token
        let access_token = JSON.parse(localStorage.getItem('access_token'));
        if (access_token) {  
            let headers = new Headers({ 'Authorization': 'Bearer ' + access_token });
            return new RequestOptions({ headers: headers });
        }
    }

}