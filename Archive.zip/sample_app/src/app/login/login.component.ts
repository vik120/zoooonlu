import { Component, OnInit,ViewContainerRef } from '@angular/core';
import { Router } from '@angular/router';
import {FormBuilder, Validators, FormControl, FormGroup} from '@angular/forms';
import { loginService } from './login.service';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import {app} from './../constant';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
    form:FormGroup = null;
    username:FormControl = null;
    password:FormControl = null;

    constructor(public router: Router, private _builder:FormBuilder,private loginService: loginService,
        public toastr: ToastsManager, vcr: ViewContainerRef,private _router: Router) {

        this.toastr.setRootViewContainerRef(vcr);
        this.username = new FormControl(null, [Validators.required,Validators.pattern(app.AppSettings.EMAIL_PATTERN)]);
        this.password = new FormControl(null, Validators.compose([Validators.required,Validators.minLength(8)]));

        this.form = this._builder.group({
            username: this.username,
            password: this.password
        });
        
    }

    ngOnInit() {
    }

    onLoggedin(value:any) {
        console.log(value)
        this.loginService.loginUser(value).subscribe(userData => {
               if(userData.messageId==200){
                localStorage.setItem('isLoggedin', 'true');
                console.log('user----------',userData)
                      this.toastr.success('welcome '+userData.message.firstname);
                      //this._router.navigate(['/dashboard']);
                      let name=userData.message.firstname;
                      let userid=userData.message.id;
                      //console.log("userid ", userid)
                        localStorage.setItem('userName',name)
                        localStorage.setItem('userId',userid)
                      setTimeout(()=>{    
                              this._router.navigate(['/dashboard']);
                         },1000);
               }

        },(err)=>{
          //console.log("dnkdd")
          this.toastr.error('Username or password is incorrect.', 'Error!');
          //this.message = "Username or password is incorrect.";
        })  
    }
}
