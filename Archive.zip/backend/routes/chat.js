
module.exports = function(app, express) {
	console.log("in chat module")
	let router = express.Router();
	let mongoose = require('mongoose');
	let server = require('http').createServer(app);
	let io = require('socket.io')(server);
	let Chat = require('../app/models/Chat/Chat.js');
	let usercontroller = require('../app/controllers/user/user.js');
	server.listen(4000);

	// socket io
	io.on('connection', function (socket) {
	  console.log('User connected');
	  socket.on('disconnect', function() {
	    console.log('User disconnected');
	  });
	  socket.on('save-message', function (data) {
	    console.log("after ad d message response is ther ---",data);
	    io.emit('new-message', { message: data });
	  });
	});

	/* GET ALL CHATS */
	router.get('/:room', function(req, res, next) {
	  Chat.find({ room: req.params.room }, function (err, chats) {
	    if (err) return next(err);
	    res.json(chats);
	  });
	});

	/* SAVE CHAT */
	router.post('/', function(req, res, next) {

		console.log("ssve mssss*------------------------------",req.body)
	  Chat.create(req.body, function (err, post) {
	    if (err) return next(err);
	    res.json(post);
	  });
	});
		
	app.use('/chat', router);
}