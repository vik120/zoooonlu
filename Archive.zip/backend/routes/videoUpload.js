//var path = require('path')
module.exports = function(app, express, passport) {
  let router = express.Router();
  let videoUploadcon = require('../app/controllers/videoUpload/videoUpload.js');
let mobileVideo = require('../app/controllers/videoUpload/mobileVideo.js');
    //save video and create gif
    router.post('/videoUpload',videoUploadcon.videoUpload)
    //getvideo
     router.get('/getvideos',videoUploadcon.getvideos)

        router.post('/mobileUpload',mobileVideo.mobileUpload)

         router.get('/getlandingPageVideos',mobileVideo.getlandingPageVideos)
        
  app.use('/videos', router);
}


