//var path = require('path')
module.exports = function(app, express, passport) {
	let router = express.Router();
	let usercontroller = require('../app/controllers/user/user.js');
	let videoUploadcon = require('../app/controllers/videoUpload/videoUpload.js');

	//addUser
	router.post('/addUser',usercontroller.addUser)
	//login
	router.post('/loginUser', passport.authenticate('local', {
		session: true, failureFlash: true 
	}), usercontroller.login);
    router.get('/getUser',usercontroller.getUser)
    //socialLogin
    router.post('/socialLogin',usercontroller.socialLogin)
	
	  //socialLogin
    router.post('/videoUpload',videoUploadcon.videoUpload)
	app.use('/userRoutes', router);
}


