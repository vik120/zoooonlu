/*var express = require('express');
var router = express.Router();
var backendcontroller = require('../app/controllers/dashboard/dashboard.js');
var sitecontroller = require('../app/controllers/site/site.js');
var path = require('path');
/* GET home page. */
var path = require('path')
module.exports = function(app, express, passport) {
	var router = express.Router();
	var userRoleController = require('../app/controllers/user/userRole.js');
	
router.get('/userRoute', function(req, res, next) {
	res.send({"name": "sunakshi"})
  //res.render('index', { title: 'Nishant' });
	//res.sendFile("index.html");
  // res.render('index.jade', {
		// 	user: JSON.stringify(user)

		// });
});
	router.post('/addRole',userRoleController.addRole)

	
app.use('/', router);
}
