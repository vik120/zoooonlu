// bearer authenticatio for checking token
module.exports = function(app,express,passport)
{
		var tokenService = require('./../app/token/tokenAuth.js');
		var userTokenObj = require('./../app/models/user/userTokens.js');
		var BearerStrategy = require('passport-http-bearer').Strategy;
		passport.use('bearer',new BearerStrategy(function(token, done) {
			tokenService.verifyToken(token, function(e, s) {
				if (e) {
					return done(e);
				}
				//console.log(e, s.sid)
				userTokenObj.findOne({
						token: token
					})
					.exec(function(err, user) {

						if (err) {
							return done(err);
						}
						if (!user) {
							return done(null, false);
						}

						if (user.admin == undefined) {
							return done(null, user.employee, {
								scope: 'all'
							});
						}
						return done(null, user.admin, {
							scope: 'all'
						});
					});
			});
		}));
}