// this module uses local-strategy and admin is login using this module
module.exports = function(app, express, passport) {
	 var tokenService = require('./../app/token/tokenAuth.js');
	 var userTokenObj = require('./../app/models/user/userTokens.js');
	 var userLoginObj = require('./../app/models/user/user.js');
	var LocalStrategy = require('passport-local').Strategy;
	var md5 = require('md5');
	
	passport.authenticate('LocalStrategy', {
		session: true
	})
	passport.use('local', new LocalStrategy(
		function(username, password, done) {
			// var newPassword = md5(password)
			
			userLoginObj.findOne({
				userEmail: username,password:password
			}, function(err, adminuser) {
				// userLoginObj.findOne({$or:[
    //       {userEmail:{$in:[username]}},
    //       {username:{$in:[username]}}
    //       ],password:newPassword},function(err, adminuser) {

				if (err) {
			
					return done(err);
				}
				/*if (adminuser.length== 0) {
					return done(null, false);
				}*/
				if(adminuser == null){
					return done(null, false);
				}
				if (adminuser.emailVerfication) {
					return done(null, {message:"Please verify your account first"});
				}
				
				//returning specific data
				//generate a token here and return 
				var authToken = tokenService.issueToken({
					sid: adminuser
				});
				// save token to db  ; 
				var tokenObj = new userTokenObj({
					"admin": adminuser._id,
					"token": authToken
				});

				tokenObj.save(function(e, s) {});
				// console.log("Type is " , adminuser.type);
				//return permission from here 
				return done(null, {
					id: adminuser._id,
				
					firstname: adminuser.firstName,
					lastname: adminuser.lastName,
					userEmail: adminuser.userEmail,
					token: authToken
				});
			});
		}
	));
	/*passport.serializeUser(adminLoginObj.serializeUser);
	passport.deserializeUser(adminLoginObj.deserializeUser);*/

	passport.serializeUser(function(adminLoginObj, done) {
		done(null, adminLoginObj);
	});

	passport.deserializeUser(function(adminLoginObj, done) {
		done(null, adminLoginObj);
	});
}