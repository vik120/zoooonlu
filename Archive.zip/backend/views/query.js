db.getCollection('sites').aggregate([
{$match:{
_id: {
$in: [ ObjectId("587f0bab4851a6dacfba83a8"),
            ObjectId("587f0bef4851a6dacfba83a9"),
               ObjectId("587f0b4f4851a6dacfba83a7") ]
      }
    }},
    {$unwind:{path:'$transmitter_id'}},
    {"$lookup": {
                   "from": "transmitters",
                   "localField": "transmitter_id",
                   "foreignField": "_id",
                   "as": "transmitters"
    }},
    {$unwind:'$transmitters'},
    {"$lookup": {
                   "from": "sensorValues",
                   "localField": "transmitter_id",
                   "foreignField": "transmitter_id",
                   "as": "sensorData"
    }},
     {$unwind:'$sensorData'},
      { "$sort": { "_id": -1 }} ,
      {$project:{
                 siteData:{siteId:'$_id',
                     siteName:'$siteName',
                     latitude:'$latitude',longitude:'$longitude',"transmitter_id":"$transmitter_id"},
                 transmitter:"$transmitters",
                     transmitter_id : '$transmitters._id',
                     sensordata:"$sensorData"
                    
                 }},

       { "$group": {
            "_id": {site_id:"$_id", transmitter_id :'$transmitter_id' },
               "siteData":{ "$first": "$siteData" },
               "transmitter":{ "$first": "$transmitter" },
               "sensordata":{ "$push": "$sensordata" }
//             "transmitterName":"$transmitterDetails.Name"
        }},
        {$project:{
                 siteData:'$siteData',
                 transmitter:{name: '$transmitter.Name',sensorData:'$sensordata'}
                    
                 }},
        { "$group": {
            "_id": '$_id.site_id',
               "siteData":{ "$first": "$siteData" },
               "transmitter":{ "$push": "$transmitter" }

        }}

])




//**********************************************************************************////////
db.getCollection('sites').aggregate([{$match:{
			_id: {
				$in: [ ObjectId("587f0bab4851a6dacfba83a8"),
                                      ObjectId("587f0bef4851a6dacfba83a9"),
                                      ObjectId("587f0b4f4851a6dacfba83a7") ]
			}
		}},{$project:{_id:1,transmitter_id:1}},{'$unwind':"$transmitter_id"},
                { "$lookup": {
                   "from": "transmitters",
                   "localField": "transmitter_id",
                   "foreignField": "_id",
                   "as": "transmitter"
    }}
    ,{'$unwind':"$transmitter"},
    { "$lookup": {
                   "from": "sensorValues",
                   "localField": "transmitter_id",
                   "foreignField": "transmitter_id",
                   "as": "sensor"
    }}
                //{$unwind:'$transmitter'},{$unwind:'$transmitter.site_Id'},{$match:{'transmitter.site_Id':{
// 				$in: [ ObjectId("587f0bab4851a6dacfba83a8"),
//                                       ObjectId("587f0bef4851a6dacfba83a9"),
//                                       ObjectId("587f0b4f4851a6dacfba83a7") ]
// 			}
//         }},{ "$group": {
//         "_id": "$transmitter.site_Id",
//         "products": { "$push": "$transmitter" }
//     }}
                ])











db.getCollection('sites').aggregate([{$match:{
			_id: {
				$in: [ ObjectId("587f0bab4851a6dacfba83a8"),
                                      ObjectId("587f0bef4851a6dacfba83a9"),
                                      ObjectId("587f0b4f4851a6dacfba83a7") ]
			}
		}},{$project:{_id:1,transmitter_id:1}},{'$unwind':"$transmitter_id"},
                { "$lookup": {
                   "from": "sensorValues",
                   "localField": "transmitter_id",
                   "foreignField": "transmitter_id",
                   "as": "transmitter"
    }},{$unwind:'$transmitter'},{$unwind:'$transmitter.site_Id'},{$match:{'transmitter.site_Id':{
				$in: [ ObjectId("587f0bab4851a6dacfba83a8"),
                                      ObjectId("587f0bef4851a6dacfba83a9"),
                                      ObjectId("587f0b4f4851a6dacfba83a7") ]
			}
        }},{ "$group": {
        "_id": "$transmitter.site_Id",
        "products": { "$push": "$transmitter" }
    }}])



/**********************---------------------------------------******************************/



db.getCollection('sites').aggregate([{$match:{
      _id: {
        $in: [ ObjectId("587f0bab4851a6dacfba83a8"),
                                      ObjectId("587f0bef4851a6dacfba83a9"),
                                      ObjectId("587f0b4f4851a6dacfba83a7") ]
      }
    }},{'$unwind':"$transmitter_id"},
                { "$lookup": {
                   "from": "sensorValues",
                   "localField": "transmitter_id",
                   "foreignField": "transmitter_id",
                   "as": "transmitter"
    }},
         {$unwind:'$transmitter'},
         {$unwind:'$transmitter.site_Id'},
{$project:{_id:1,transmitter_id:1,transmitter:1,isequal : {$eq:['$_id','$transmitter.site_Id']}}},


    {$match:{'transmitter.site_Id':{
        $in: [ ObjectId("587f0bab4851a6dacfba83a8"),
                                      ObjectId("587f0bef4851a6dacfba83a9"),
                                      ObjectId("587f0b4f4851a6dacfba83a7") ]
      },
                        isequal:true
       // _id:"$transmitter.site_Id"
      }},
                       
         { "$sort": { "transmitter._id": -1, "_id": -1 }},
          { "$group": {
            "_id": "$transmitter.transmitter_id",
               "site_id":{"$first":"$transmitter.site_Id"},
               "trans_id": { "$first": "$transmitter.transmitter_id" },
            "MainsActual": { "$first": "$transmitter.MainsActual" },
            "FwdPwrActual": { "$first": "$transmitter.FwdPwrActual" }
            
        }},
        {$project:{_id:'$_id',site_id:'$site_id', 
            transmitter:{id:'$trans_id',MainsActual : '$MainsActual'}}},

          { "$group": {
                 "_id": "$site_id",
                  "products": { "$push": "$transmitter" }
                 
          }}

        ])

        /*************last *********----------------
        **/

        db.getCollection('sites').aggregate([{$match:{
      _id: {
        $in: [ ObjectId("587f0bab4851a6dacfba83a8"),
                                      ObjectId("587f0bef4851a6dacfba83a9"),
                                      ObjectId("587f0b4f4851a6dacfba83a7") ]
      }
    }}                ,{'$unwind':"$transmitter_id"},
                { "$lookup": {
                   "from": "sensorValues",
                   "localField": "transmitter_id",
                   "foreignField": "transmitter_id",
                   "as": "transmitter"
    }}
    ,
         {$unwind:'$transmitter'},
         
        { "$sort": { "transmitter._id": -1 }} , 
           { "$group": {
            "_id": { "site_id":"$_id","transmitter_id": "$transmitter.transmitter_id"},
            
               "_ids":{"$first":"$_id"},
            "trans_id": { "$first": "$transmitter.transmitter_id" },
            "MainsActual": { "$first": "$transmitter.MainsActual" },
            "FwdPwrActual": { "$first": "$transmitter.FwdPwrActual" }
              
        }}
        ,  
 {$project:{_id:1,transmitter_id:1,transmitter:1,
     transmitter:{id:'$trans_id',MainsActual : '$MainsActual'},
     isequal : {$eq:['$_ids','$_id.site_id']}}},
    {
        $match:{'_id.site_id':{
        $in: [ ObjectId("587f0bab4851a6dacfba83a8"),
                                      ObjectId("587f0bef4851a6dacfba83a9"),
                                      ObjectId("587f0b4f4851a6dacfba83a7") ]
      },
                        isequal:true
      
      }},
// //                        
//          { "$sort": { "transmitter._id": -1, "_id": -1 }}
//          ,
//           { "$group": {
//             "_id": "$transmitter.transmitter_id",
//                "site_id":{"$first":"$transmitter.site_Id"},
//                "trans_id": { "$first": "$transmitter.transmitter_id" },
//             "MainsActual": { "$first": "$transmitter.MainsActual" },
//             "FwdPwrActual": { "$first": "$transmitter.FwdPwrActual" }
//             
//         }},
//         {$project:{_id:'$_id',site_id:'$site_id', 
//             transmitter:{id:'$trans_id',MainsActual : '$MainsActual'}}},
// 
          { "$group": {
                 "_id": "$_id.site_id",
                  "products": { "$push": "$transmitter" }
                 
          }}

        ])


        /***************-------------------------------------///////////////*/

        db.getCollection('sites').aggregate([{$match:{
      _id: {
        $in: [ ObjectId("587f0bab4851a6dacfba83a8"),
                                      ObjectId("587f0bef4851a6dacfba83a9"),
                                      ObjectId("587f0b4f4851a6dacfba83a7") ]
      }
    }},
                {'$unwind':"$transmitter_id"},
                { "$lookup": {
                   "from": "sensorValues",
                   "localField": "transmitter_id",
                   "foreignField": "transmitter_id",
                   "as": "transmitter"
    }},
      {$unwind:'$transmitter'},
         { "$lookup": {
                   "from": "transmitters",
                   "localField": "transmitter.transmitter_id",
                   "foreignField": "_id",
                   "as": "transmitterDetails"
    }},{$unwind:'$transmitterDetails'},
        { "$sort": { "transmitter._id": -1 }} , 
        {$unwind:'$transmitter.site_Id'},
           { "$group": {
            "_id": { "site_id":"$_id","transmitter_id": "$transmitter.transmitter_id"},
            "_ids":{"$first":"$_id"},
            "siteName":{"$first":"$siteName"},
            "latitude":{"$first":"$latitude"},
            "longitude":{"$first":"$longitude"},
            "trans_id": { "$first": "$transmitter.transmitter_id" },
            "MainsActual": { "$first": "$transmitter.MainsActual" },
            "FwdPwrActual": { "$first": "$transmitter.FwdPwrActual" },
            "siteidfromtrans": { "$first": "$transmitter.site_Id" },
            "transmitterName": { "$first": "$transmitterDetails.Name" }
              
        }},
          
             {$project:{_id:1,transmitter_id:1,transmitter:1,
                 siteData:{siteId:'$_ids',siteName:'$siteName'},
                 transmitter:{id:'$trans_id',MainsActual : '$MainsActual',
                     isequal : {$eq:['$_ids','$siteidfromtrans']},
                     transmitterName:"$transmitterName"}
                 }},
 
          { "$group": {
                 "_id": "$_id.site_id",
            "siteData":{ "$first": "$siteData" },          
                  "products": { "$push": "$transmitter" }
                  
                 
          }} 
// 
     ])


        /*****************************************////////////////

        db.getCollection('sites').aggregate([
{$match:{
_id: {
$in: [ ObjectId("587f0bab4851a6dacfba83a8"),
            ObjectId("587f0bef4851a6dacfba83a9"),
               ObjectId("587f0b4f4851a6dacfba83a7") ]
      }
    }},
    {$unwind:{path:'$transmitter_id'}},
    {"$lookup": {
                   "from": "transmitters",
                   "localField": "transmitter_id",
                   "foreignField": "_id",
                   "as": "transmitters"
    }},
    {$unwind:'$transmitters'},
    {"$lookup": {
                   "from": "sensorValues",
                   "localField": "transmitter_id",
                   "foreignField": "transmitter_id",
                   "as": "sensorData"
    }},
     {$unwind:'$sensorData'},
      { "$sort": { "_id": -1 }} ,
      {$project:{
                 siteData:{siteId:'$_id',
                     siteName:'$siteName',
                     latitude:'$latitude',longitude:'$longitude',"transmitter_id":"$transmitter_id"},
                 transmitter:"$transmitters",
                     sensordata:"$sensorData"
                    
                 }},

       { "$group": {
            "_id": "$_id",  
               "siteData":{ "$first": "$siteData" },
               "transmitter":{ "$first": "$transmitter" },
               "sensordata":{ "$first": "$sensordata" }
            
//             "transmitterName":"$transmitterDetails.Name" 
              
        }},
//          { "$group": {
//             "_id": "$_id.site_id",  
//                "siteData":{ "$first": "$siteData" },
//                "transmitter":{ "$first": "$transmitter" },
//                "sensordata":{ "$first": "$sensordata" }
//             
// //             "transmitterName":"$transmitterDetails.Name" 
//               
//         }},
//               
//              
//          { "$group": {
//             "_id":  "$_id.site_id"
//             
// //             "transmitterName":"$transmitterDetails.Name" 
//               
//         }},
        
//     {$project:{
//         'sitedetail':{'siteId':"$_id",'siteName':"$siteName",'location':"$location"
//             ,'latitude':"$latitude",'longitude':"$longitude"},"transmitterDetail":"$transmitters",
//             "sensorDetail":"$sensorData",
//             isequal : {$and:[{$eq:['$_id','$sitedetail.siteId']},
//                     {$eq:['$transmitterDetail._id','$transmitterDetail._id']}
//                     ]}
//         }
//         
//         }
])

        /*************************************************************************-*/

        db.getCollection('sites').aggregate([
{$match:{
_id: {
$in: [ ObjectId("587f0bab4851a6dacfba83a8"),
            ObjectId("587f0bef4851a6dacfba83a9"),
               ObjectId("587f0b4f4851a6dacfba83a7") ]
      }
    }},
    {$unwind:{path:'$transmitter_id'}},
    {"$lookup": {
                   "from": "transmitters",
                   "localField": "transmitter_id",
                   "foreignField": "_id",
                   "as": "transmitters"
    }},
    {$unwind:'$transmitters'},
    {"$lookup": {
                   "from": "sensorValues",
                   "localField": "transmitter_id",
                   "foreignField": "transmitter_id",
                   "as": "sensorData"
    }},
     {$unwind:'$sensorData'},
      { "$sort": { "_id": -1,"sensorData._id":-1 }} ,
      {$project:{
                 siteData:{siteId:'$_id',
                     siteName:'$siteName',
                     latitude:'$latitude',longitude:'$longitude',"transmitter_id":"$transmitter_id"},
                 transmitter:"$transmitters",
                     transmitter_id : '$transmitters._id',
                     sensordata:"$sensorData",
                     sensordataId:"$sensorData.site_Id",
//                       isequal : {$and:[{$eq:['$_id','$sensorData.site_Id[0]']},
//                     {$eq:['$transmitter_id','$transmitter_id']}
//                     ]}
//                      
//                     
                 }},
                {$unwind:'$sensordataId'},
                 {$project:{
                 siteData:"$siteData",
                 transmitter:"$transmitter",
                     transmitter_id : '$transmitter_id',
                     sensordata:"$sensordata",
                     sensordataId:"$sensorData.site_Id",
                      isequal : {$and:[{$eq:['$_id','$sensordataId']},
                    {$eq:['$transmitter_id','$transmitter_id']}
                    ]}
                     
                    
                 }},

        { "$group": {
             "_id": {site_id:"$_id", transmitter_id :'$transmitter_id' },
                "siteData":{ "$first": "$siteData" },
                "transmitter":{ "$first": "$transmitter" },
               "sensordata":{ "$first": "$sensordata" },
               "isequal":{"$first":"$isequal"}
             
         }},
        {$project:{
                 siteData:'$siteData',
                 transmitter:{name: '$transmitter.Name',sensorData:'$sensordata',isequal:"$isequal"}
                    
                 }},
//                  {
//             "_id": '$_id.site_id',
//                "siteData":{ "$first": "$siteData" },
//                "transmitter":{ "$push": "$transmitter" }
// 
//         }}
        
        
        
         { "$group": {
            "_id": "$_id.site_id",  
               "siteData":{ "$first": "$siteData" },
               "transmitter":{ "$first": "$transmitter" }
//                ,
//                "sensordata":{ "$first": "$sensordata" }
            
//             "transmitterName":"$transmitterDetails.Name" 
              
        }},
//               
//              
//          { "$group": {
//             "_id":  "$_id.site_id"
//             
// //             "transmitterName":"$transmitterDetails.Name" 
//               
//         }},
        
//     {$project:{
//         'sitedetail':{'siteId':"$_id",'siteName':"$siteName",'location':"$location"
//             ,'latitude':"$latitude",'longitude':"$longitude"},"transmitterDetail":"$transmitters",
//             "sensorDetail":"$sensorData",
//             isequal : {$and:[{$eq:['$_id','$sitedetail.siteId']},
//                     {$eq:['$transmitterDetail._id','$transmitterDetail._id']}
//                     ]}
//         }
//         
//         }
])