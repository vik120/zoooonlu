module.exports = function(app, express, passport) {
	console.log('pssport---',passport)
	
}