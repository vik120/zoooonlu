
const messages = {
"mailUser":'osgroup.sdei@gmail.com',
"mailPass":'378'
}
var obj = {
	messages: messages
};

module.exports = obj;
