var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var roleSchema = new Schema({
	userRole:{
		type:String  
	},
	type:{
		type:Number //[user(1),masterAdmin(2) staff(3)]
	},
	created: {
		type: Date,
		default: Date.now()
	},
	modified: {
		type: Date,
		default: Date.now()
	}

}, {
	collection: 'roles'
});


var roleObj = mongoose.model('roles', roleSchema);
module.exports = roleObj;