var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var landingPageSchema = new Schema({
	videoLink:{
		type:String  
	},
	is_deleted:{
	 	type:Boolean, 
	 	default:false
	},
	created: {
		type: Date,
		default: new Date()
	},
	modified: {
		type: Date,
		default: new Date()
	}

}, {
	collection: 'landingPages'
});


var landingPageObj = mongoose.model('landingPages', landingPageSchema);
module.exports =landingPageObj;