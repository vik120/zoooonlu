var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var videoSchema = new Schema({
	videoLink:{
		type:String  
	},
	gifLink:{
		type:String
	},
	created: {
		type: Date,
		default: new Date()
	},
	modified: {
		type: Date,
		default: new Date()
	}

}, {
	collection: 'productvideos'
});


var videoObj = mongoose.model('productvideos', videoSchema);
module.exports =videoObj;