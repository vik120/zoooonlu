var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var userSchema = new Schema({
	userEmail:{
		type:String,
		//require:"Email id is required",
		unique:true  
	},
	firstName: {
		type: String,
		//required: 'Please enter the first name.'
	},
	lastName: {
		type: String,
	},
	username:{type:String,
		//require:"Username is required",
		unique:true },
	password: {
		type: String,
		//required: 'Please enter the password.'
	},
	loginType: {
		type: Number,
		default:1 //[1-simple,2-facebook,3-googleplus]
	},
	userType: {
		type: Number,
		default:1
	},
	phoneNo: {
		type: Number,
		default:1
	},
	userId:{type: String},
	// city: {
	// 	type: String,
	// 	default:1
	// },
	// state: {
	// 	type: String,
	// 	default:1
	// },
	// zip: {
	// 	type: Number,
	// 	default:1
	// },
	is_deleted:{
	 	type:Boolean, 
	 	default:false
	},
	paypalEmail: {
		type: String
	},
	created: {
		type: Date,
		default: new Date()
	},
	modified: {
		type: Date,
		default: new Date()
	}
}, {
	collection: 'users'
});
userSchema.path('firstName').validate(function(value) {
	var validateExpression = /^[ A-Za-z']*$/;
	return validateExpression.test(value);
}, ",Please enter a valid first name.");


userSchema.path("lastName").validate(function(value) {
	var validateExpression = /^[ A-Za-z']*$/;
	return validateExpression.test(value);
}, ",Please enter a valid last name.");

userSchema.path("userEmail").validate(function(value) {
	var validateExpression = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
	return validateExpression.test(value);
}, ",Please enter a valid email address.");



var userObj = mongoose.model('users', userSchema);
module.exports = userObj;
