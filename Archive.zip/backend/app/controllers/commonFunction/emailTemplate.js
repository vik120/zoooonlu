// var nodemailer = require('nodemailer');
// var mongoose = require('mongoose');
// var constantObj = require('./../../../constants.js');

// exports.sendEmail = function(userEmail){
// 	console.log("m her send email")

// 	  var message = '<html><body style="background-color: #f2f2f2"><div style="width:90%; padding: 15px; background-color: #fff; box-shadow: 3px 3px #dddddd;"><div style="padding-top:10px; background-color: #f0f0f0; height: 100px"></div><div style="padding-top:10px">Hi,</div><div style="padding-top:30px">test mail.</div><div style="padding-top:20px">If you did not initiate this request, then ignore this message.</div><div style="padding-top:20px">test mail.</div><div style="padding-top:30px">RresetUrl</a></div><div style="padding-top:50px">Regards,<br>Opio RF</div></div></body></html>'
// 	transporter.sendMail({
//         from: 'IOT Sysyem',
//         to:"james.craig@opio.io",   
//         subject: 'alert message ',
//         html: message
// })
// }

var nodemailer = require('nodemailer');
var mongoose = require('mongoose');
var constantObj = require('./../../../constants.js');
exports.sendEmail = function(userEmail,email)
{
	var keys = [];
	var values=[];
	for(var k in userEmail)
		keys.push(k);

	var count = Object.keys(userEmail).length;

	var data="";
	for(var i=0;i++;){
		data=data+temp;
	}
	var siteName=email.siteName;
	var message = 'Hi,Red Alert Noticed In '+siteName+'.'+data+'If you did not initiate this request, then ignore this message.test mail.Regards,Opio RF';
	console.log("messages *********************" , message)
	transporter.sendMail({
			from: 'OPIO Sysyem',
			// to: userEmail,
			// to:"james.craig@opio.io" ,
			to:"sunakshi.thakur@smartdatainc.net" ,
			subject: 'alert message ',
			html: message
		})
}
