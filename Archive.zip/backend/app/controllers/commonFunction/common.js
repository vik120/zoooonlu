var mongoose = require('mongoose');
var constantObj = require('./../../../constants.js');
var nodemailer = require('nodemailer');

var crypto = require('crypto'),
    algorithm = 'aes-256-ctr',
    password = 'd6F3Efeq';




exports.encrypt = function(text) {

    var cipher = crypto.createCipher(algorithm, password)
    var crypted = cipher.update(text, 'utf8', 'hex')
    crypted += cipher.final('hex');
    return crypted;
}

exports.decrypt = function(text) {
    var decipher = crypto.createDecipher(algorithm, password)
    var dec = decipher.update(text, 'hex', 'utf8')
    dec += decipher.final('utf8');
    return dec;
}

//var hw = encrypt("hello world")
// outputs hello world
//console.log(decrypt(hw));


exports.makeid = function() {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for (var i = 0; i < 15; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
}
exports.sendMail = function(){
    console.log("m herer in send mail function")
      var transporter = nodemailer.createTransport({
                            service: 'gmail',
                            auth: {
                                user: constantObj.messages.mailUser,
                                pass: constantObj.messages.mailPass
                            }
     });
}
exports.sendResponseForsuccess = function(res,finaldata,message) {

        res.status(200).send({
                'status': 'success',
                'messageId': 200,
                'message': message,
                'data': finaldata
        });
}

exports.sendResponseForfailure= function(res,message) {
        res.status(400).send({
                'status': 'failure',
                'messageId': 400,
                'message': message
        });
   
}