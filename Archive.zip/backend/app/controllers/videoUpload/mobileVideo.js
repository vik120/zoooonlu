let formidable = require('formidable');
let fs = require('fs');
let baseUrl = __dirname + "/../../../uploads/mobile";
let path = require("path");
var commonjs = require('./../commonFunction/common.js');
let message = "";
var landingPageObj = require('./../../models/videoUpload/mobileLadingpage.js');

exports.mobileUpload = function(req, res) {
        let form = new formidable.IncomingForm();
        //form.uploadDir = baseUrl //set upload directory
        form.keepExtensions = true; //keep file extension
        form.multiples = true;
        form.parse(req, function(err, fields, files) {
        	video__anyToMP4OrWebm(files.file,res)
        });
    }
function video__anyToMP4OrWebm(file,res) {
	console.log("file fjgfj",file )
    let filepath = file.path
    if (file  !== null || file !== undefined) {
    	let dateTime = new Date().toISOString().replace(/T/, '').replace(/\..+/, '').split(" ");
    	let randomString = Math.random()
    	let outputFile = '';
        let extension = '';
        extension = file.name.split('.').pop();
        extensionUpper = extension.toUpperCase();
        let fileName = dateTime + "." + extension;
        switch (extensionUpper) {
            case 'WEBM':
                outputFile = fileName.replace('.' + extension, '.mp4');

                __convertVideo(fileName, outputFile,filepath,res);
                break;

            case 'MP4':
                outputFile = fileName.replace('.' + extension, '.mp4');
                __convertVideo(fileName, outputFile,filepath,res);
                break;

            case 'MOV':
                outputFile = fileName.replace('.' + extension, '.mp4');
                __convertVideo(fileName, outputFile,filepath,res);
                break;

            default:

                if (extension != '' && extension != null) {
                    outputFile = inputFile.replace('.' + extension, '.mp4');
                    __convertVideo(inputFile, outputFile,filepath,res);
                }
                break;
        }
        /*if(extensionUpper == 'WEBM' || extensionUpper == 'MP4'){
            let input_path =  path.resolve(__dirname + '/../../public/uploads/' + inputFile);
            let input_final_path =  path.resolve(__dirname + '/../../public/uploads/video/' + inputFile);
        }*/
    }
    return;
}
function __convertVideo(inputFile, outputFile,filepath,res) { 
    fs.rename(filepath, baseUrl  + "/" + outputFile, function(err) {
        if (err) {
                throw err;
        } else {
	        let json ={};
			json.videoLink = "/mobile/"+outputFile;
		console.log("final json",json)
     		landingPageObj(json).save(json)
		.then(list=>{
              message = "video savedsuccesfully"
              commonjs.sendResponseForsuccess(res,list,message)
             })
            .catch(err=>{
            	console.log("err",err)
               message = "error while uploading video"
               commonjs.sendResponseForfailure(res,message)
             })
        }
    });
}

exports.getlandingPageVideos = function(req,res){
    let message =''
        landingPageObj.find({})
        .then(videoList=>{
            console.log(videoList)
             message = "video listing"
             commonjs.sendResponseForsuccess(res,videoList,message)
        })
        .catch(err=>{
            message = "Not video Uploaded yet"
            commonjs.sendResponseForfailure(res,message)

        })

}