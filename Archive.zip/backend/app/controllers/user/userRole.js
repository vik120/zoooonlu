var userRoleObj = require('./../../models/userRole/userRole.js');
var mongoose = require('mongoose');
mongoose.Promise = Promise; 

exports.addRole = function(req,res){
	let json = req.body
	userRoleObj(json).save(json)
	.then(list=>{
		res.status(200).send({
                'status': 'success',
                'messageId': 200,
                'message': "success",
                'data': list
        });
    })
	.catch(err=>{
		res.status(400).send({
                'status': 'failed',
                'messageId': 400,
                'message': "error while adding Role"
        });
	})
}