
 var mongoose = require('mongoose');
// mongoose.Promise = Promise; 
var userObj = require('./../../models/user/user.js');
var commonjs = require('./../commonFunction/common.js');
let message = "";
     /*---------------------------------------------
       * @Date:        13-Sep-17
       * @Method :     ADD Function
       * Created By:   Sunakshi Thakur
       * Modified On:  -
       * @Purpose:     ADD User function
     ----------------------------------------------*/
exports.addUser = function(req,res){
	let json = req.body
	console.log("user data ",json)
	userObj(json).save(json)
	.then(list=>{
		res.status(200).send({
                'status': 'success',
                'messageId': 200,
                'message': "success",
                'data': list
        });
    })
	.catch(err=>{
		let errorMessage = '';
	    let messages = '';
		switch (err.name) {
            case 'ValidationError':
            for (field in err.errors) {
                if (errorMessage == "") {
                	 errorMessage = field + ":- " + err.errors[field].message;
                } else {

                    errorMessage += ", " + field + ":- " + err.errors[field].message;
                }
            } //forbreak;} //switch
            outputJSON = {
                'status': 'failure',
                'messageId': 401,
                'message': errorMessage
            };
            res.jsonp(outputJSON);
        }
	})
}
  /*---------------------------------------------
       * @Date:        13-Sep-17
       * @Method :     Login Function
       * Created By:   Sunakshi Thakur
       * Modified On:  -
       * @Purpose:     Login function for both platform
     ----------------------------------------------*/
exports.login = function(req, res) {
    if (res.req.user.token) {
        console.log("/**/*/*/*/",res.req.user)
        res.jsonp({
            'status': 'success',
            'messageId': 200,
            'message': res.req.user

        });
    }
}
 /*---------------------------------------------
       * @Date:        13-Sep-17
       * @Method :     Social Login Function
       * Created By:   Sunakshi Thakur
       * Modified On:  -
       * @Purpose:     Sociallogin  function for mobile App
     ----------------------------------------------*/
exports.socialLogin = function(req,res){
  let userdata =req.body;
  
  userObj.findOne({userId:userdata.userId},{"firstName":1,"lastName":1,"userEmail":1})
    .then(userList=>{
      if(userList){
        message = "user login succesfully"
        commonjs.sendResponseForsuccess(res,userList,message)
      }else {
        //save user than login 
        console.log("else part")
        let details = {};
            if (req.body.firstName) {
                details.firstName = req.body.firstName;
            }
            if (req.body.lastName) {
                details.lastName = req.body.lastName;
            }
            if (req.body.phone) {
                details.phone = req.body.phone;
            }
            details.loginType = req.body.loginType;
            details.userId = req.body.userId;
            userObj(details).save(details)
            .then(list=>{
              message = "user login succesfully"
              commonjs.sendResponseForsuccess(res,userList,message)
             })
            .catch(err=>{
               message = "error while login with facebook"
               commonjs.sendResponseForfailure(res,message)
             }) 
      }
    })
    .catch(err=>{
      console.log(err)
      message = "error while login with facebook"
      commonjs.sendResponseForfailure(res,message)
    }) 
}
  /*---------------------------------------------
       * @Date:        13-Sep-17
       * @Method :     get Function
       * Created By:   Sunakshi Thakur
       * Modified On:  -
       * @Purpose:    GET All Users function
     ----------------------------------------------*/

exports.getUser = function(req,res){
    userObj.find({_id:{$ne:req.id}}).sort({ "_id": -1 })
    .then(userList=>{
      message="User Listing"
      commonjs.sendResponseForsuccess(res,userList,message)
      
    })
    .catch(err=>{
      message="users not found"
      commonjs.sendResponseForsuccess(res,message)
        })
}
