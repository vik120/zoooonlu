
var mongoose = require('mongoose');
mongoose.Promise = require('bluebird');

 //mongoose.connect('mongodb://localhost/ecommerce');
mongoose.connect('mongodb://e-commerce:e-commerce2780@localhost:27017/e-commerce',{useMongoClient: true});

var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error'));
db.on('connected', console.error.bind(console, 'connected'));

