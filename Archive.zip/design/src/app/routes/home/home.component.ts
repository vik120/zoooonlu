import { Component, OnInit, ViewEncapsulation, Inject, forwardRef, HostListener } from '@angular/core';
import { MasonryOptions, MasonryModule } from 'angular2-masonry';

// import { AngularMasonry } from 'angular2-masonry/src/masonry';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class HomeComponent implements OnInit {

  public testimonals : any[] = [
    {
      userPic: 'user-1.png',
      userTestimonial: 'Kids grow so fast. When my two kids were only toddlers, I bought them a tricycle and a pedal-less bike balancer. When they got bigger, we moved on to 16-inch two wheelers. It was so much fun teaching them how to balance by holding on to the bike seat as I ran along side them. As of now, they’ve graduate to full 20-inch wheels with hand brakes. When we got them new bikes, the old ones just took up space in our garage. Luckily, I found Zoonlu.',
      userName: 'Jan Losert',
      userDestination: 'New York'
    },
    {
      userPic: 'user-1.png',
      userTestimonial: 'Kids grow so fast. When my two kids were only toddlers, I bought them a tricycle and a pedal-less bike balancer. When they got bigger, we moved on to 16-inch two wheelers. It was so much fun teaching them how to balance by holding on to the bike seat as I ran along side them. As of now, they’ve graduate to full 20-inch wheels with hand brakes. When we got them new bikes, the old ones just took up space in our garage. Luckily, I found Zoonlu.',
      userName: 'Jan Losert',
      userDestination: 'New York'
    },
    {
      userPic: 'user-1.png',
      userTestimonial: 'Kids grow so fast. When my two kids were only toddlers, I bought them a tricycle and a pedal-less bike balancer. When they got bigger, we moved on to 16-inch two wheelers. It was so much fun teaching them how to balance by holding on to the bike seat as I ran along side them. As of now, they’ve graduate to full 20-inch wheels with hand brakes. When we got them new bikes, the old ones just took up space in our garage. Luckily, I found Zoonlu.',
      userName: 'Jan Losert',
      userDestination: 'New York'
    },
    {
      userPic: 'user-1.png',
      userTestimonial: 'Kids grow so fast. When my two kids were only toddlers, I bought them a tricycle and a pedal-less bike balancer. When they got bigger, we moved on to 16-inch two wheelers. It was so much fun teaching them how to balance by holding on to the bike seat as I ran along side them. As of now, they’ve graduate to full 20-inch wheels with hand brakes. When we got them new bikes, the old ones just took up space in our garage. Luckily, I found Zoonlu.',
      userName: 'Jan Losert',
      userDestination: 'New York'
    },
  ]

  public product: any[] = [
    {
      productimg: 'product-1.jpg',
      productName: 'Mobile Sale',
      productPrice: 140,
      productDestination: 'New York, USA',
      productView: 303
    },
    {
      productimg: 'product-2.jpg',
      productName: 'Mobile Sale',
      productPrice: 140,
      productDestination: 'New York, USA',
      productView: 303
    },
    {
      productimg: 'product-3.jpg',
      productName: 'Mobile Sale',
      productPrice: 140,
      productDestination: 'New York, USA',
      productView: 303
    },
    {
      productimg: 'product-6.jpg',
      productName: 'Mobile Sale',
      productPrice: 140,
      productDestination: 'New York, USA',
      productView: 303
    },
    {
      productimg: 'product-4.jpg',
      productName: 'Mobile Sale',
      productPrice: 140,
      productDestination: 'New York, USA',
      productView: 303
    },
    {
      productimg: 'product-5.jpg',
      productName: 'Mobile Sale',
      productPrice: 140,
      productDestination: 'New York, USA',
      productView: 303
    },
    {
      productimg: 'product-1.jpg',
      productName: 'Mobile Sale',
      productPrice: 140,
      productDestination: 'New York, USA',
      productView: 303
    },
    {
      productimg: 'product-2.jpg',
      productName: 'Mobile Sale',
      productPrice: 140,
      productDestination: 'New York, USA',
      productView: 303
    },
    {
      productimg: 'product-3.jpg',
      productName: 'Mobile Sale',
      productPrice: 140,
      productDestination: 'New York, USA',
      productView: 303
    },
    {
      productimg: 'product-6.jpg',
      productName: 'Mobile Sale',
      productPrice: 140,
      productDestination: 'New York, USA',
      productView: 303
    },
    {
      productimg: 'product-4.jpg',
      productName: 'Mobile Sale',
      productPrice: 140,
      productDestination: 'New York, USA',
      productView: 303
    },
    {
      productimg: 'product-5.jpg',
      productName: 'Mobile Sale',
      productPrice: 140,
      productDestination: 'New York, USA',
      productView: 303
    },
    {
      productimg: 'product-1.jpg',
      productName: 'Mobile Sale',
      productPrice: 140,
      productDestination: 'New York, USA',
      productView: 303
    },
     
     
     
  ];

public myOptions: MasonryOptions = { 
  transitionDuration: '0.8s',
  columnWidth: 285,
  percentPosition: true,
  resize: true,
  fitWidth: true,
  initLayout: true,
  gutter: 15,
};

public shiftRight: boolean = false;

public useImagesLoaded: boolean;

  constructor(
    // private anuglarMasonay: MasonryModule
  ) { }

  ngOnInit() {
  }

  toggleFilter(){
    this.shiftRight = !this.shiftRight;
  //  this.masonryContainer.layout();
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    // this.anuglarMasonay._msnry.reloadItems();
 
  }

}
