import {Route, RouterModule} from '@angular/router'; 
import { HomeComponent } from './routes/home/home.component';

export const Routing = RouterModule.forRoot([
    {
        path: '',
        component: HomeComponent
    }
]);