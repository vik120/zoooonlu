import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {Routing} from './app.routing';

import { MasonryModule } from 'angular2-masonry';
import { OwlModule } from 'ngx-owl-carousel';
import { IonRangeSliderModule } from "ng2-ion-range-slider";
import {ScrollToModule} from 'ng2-scroll-to';
import { AccordionModule, ModalModule } from 'ngx-bootstrap';


import { AppComponent } from './shared/app/app.component';
import { HeaderComponent } from './shared/header/header.component';
import { HomeComponent } from './routes/home/home.component';
import { SidebarComponent } from './shared/sidebar/sidebar.component';
import { ProductBoxComponent } from './shared/product-box/product-box.component';
import { TestimonialsComponent } from './shared/testimonials/testimonials.component';
import { FooterComponent } from './shared/footer/footer.component';
import { ProductDirective } from './shared/product-box/product.directive';
 
 

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    SidebarComponent,
    ProductBoxComponent,
    TestimonialsComponent,
    FooterComponent,
    ProductDirective,
    
  ],
  imports: [
    BrowserModule,
    Routing, 
    MasonryModule,
    OwlModule, 
    IonRangeSliderModule,
    ScrollToModule.forRoot(),
    AccordionModule.forRoot(),
    ModalModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
