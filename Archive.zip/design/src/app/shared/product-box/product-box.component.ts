import { element } from 'protractor';
import { Component, OnInit, ViewEncapsulation, Input } from '@angular/core';
import { ProductDirective } from './product.directive';

@Component({
  selector: 'app-product-box',
  templateUrl: './product-box.component.html',
  styleUrls: ['./product-box.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ProductBoxComponent implements OnInit {

  @Input('productinfo') element:{
    productImage: string,
    productName: string,
    productPrice: number,
    productDestination: string,
    productView: number
  }

  @Input() productImage: string;
  @Input() productName: string;
  @Input() productPrice: number;
  @Input() productDestination: string;
  @Input() productView: number;

  constructor() { }

  ngOnInit() {
    console.log(this.productImage);
  }

}
