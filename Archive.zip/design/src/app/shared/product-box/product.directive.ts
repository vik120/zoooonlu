 
import { Directive, ElementRef, HostListener, OnInit } from '@angular/core';

@Directive({
  selector: '[appProduct]'
})
export class ProductDirective implements OnInit {

  constructor(private elementRef: ElementRef) {
    
      }

      ngOnInit(){
        console.log(this.elementRef.nativeElement.offsetHeight);
      }

}
