import { Component, OnInit, ViewEncapsulation, HostListener, Inject, Input, TemplateRef } from '@angular/core';
import { DOCUMENT } from "@angular/platform-browser";
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/modal-options.class';
 

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class HeaderComponent implements OnInit {
  public fixed: boolean = false; 
  public openMenu: boolean = false;
  public showBtn: boolean = false;
  public modalRef: BsModalRef;
  public config = {
    animated: true,
    keyboard: true,
    backdrop: true,
    ignoreBackdropClick: true
  }; 
  showBox: string = 'initialBox';
 


  constructor(@Inject(DOCUMENT) private document: Document, private modalService: BsModalService) { }

  ngOnInit() {
    
  }

  @HostListener("window:scroll", [])
  onWindowScroll() {
      let num = window.pageYOffset || this.document.documentElement.scrollTop || this.document.body.scrollTop || 0;
     
      if ( num > 100 ) {
        
        this.fixed = true;
      }
      else if (this.fixed && num < 100) {
         
        this.fixed = false;
      }
  }

  public open(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, Object.assign({}, this.config, {class: 'userinfo-modal gray modal-lg'}));
  }

  public uploadImage(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, Object.assign({}, this.config, {class: 'gray'}));
  }

  showBoxEvent(e){
    this.showBox = e;
  }

}
