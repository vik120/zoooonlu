import { Component, OnInit, ViewEncapsulation, Input } from '@angular/core';

@Component({
  selector: 'app-testimonials',
  templateUrl: './testimonials.component.html',
  styleUrls: ['./testimonials.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class TestimonialsComponent implements OnInit {
  @Input('testimonial') element:{
    userPic: string,
    userTestimonial: string,
    userName: string, 
    userDestination: string
  }

@Input() userPic: string;
@Input() userTestimonial: string;
@Input() userName: string;
@Input() userDestination: string


  constructor() { }

  ngOnInit() {
  }

}
