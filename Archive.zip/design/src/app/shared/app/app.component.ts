import { Component, ViewEncapsulation, Inject, OnInit } from '@angular/core';
import { DOCUMENT } from '@angular/platform-browser';
import {Event, NavigationCancel, NavigationEnd, NavigationError, NavigationStart, Router} from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AppComponent implements OnInit {
  title = 'app';

  constructor(@Inject(DOCUMENT) private document: Document, private router: Router) { }


  ngOnInit() {
    this.router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
        return;
      }
      window.scrollTo(0, 0)
    });
  }

  public onDeactivate() {
    document.body.scrollTop = 0;
  }

  onEdit(){
    document.body.scrollTop = document.documentElement.scrollTop = 0;
  }
}
